double :: [Int] -> [Int]
double lis
   |lis == [] = []
   |otherwise = (2 * head lis) : double (tail lis)