membership :: [Int] -> Int -> Bool
membership lis n
   |lis == [] = False
   |head lis == n = True
   |otherwise = membership (tail lis) n