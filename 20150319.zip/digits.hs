digits :: String -> String
digits str 
    |str == [] = []
	|(head str) >= '0' && (head str) <= '9' = (head str) : digits (tail str)
	|otherwise = digits (tail str)