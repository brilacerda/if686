sumPairs :: [Int] -> [Int] -> [Int]
sumPairs lis ta
   |lis == [] && ta == [] = []
   |lis == [] && ta /= [] = tail ta
   |lis /= [] && ta == [] = tail lis
   |otherwise = (head lis + head ta) : sumPairs (tail lis) (tail ta)